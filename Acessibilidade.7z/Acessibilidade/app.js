$(document).ready(function(){
    contraste = 1;
    $("#altoContraste").click(function(contraste){
        $(document).css("background", "black")
        if(contraste == 1){
            $(".content").css("background-color", "black");
            return 0;
        }else{

        }
    })
});